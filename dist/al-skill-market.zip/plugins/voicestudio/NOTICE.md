# VoiceStudio 语音包（本地）

本目录内容来自上游开源仓库，遵循其原始许可证（见同目录 LICENSE）。

- 上游：https://github.com/debpalash/VoiceStudio
- 许可证：AGPL-3.0
- 打包日期：2026-11-24
- 打包者改动：仅复制文件、重新组织目录结构，未修改技能正文。

技能清单（2 个）：voicestudio, voicestudio-maintainer
